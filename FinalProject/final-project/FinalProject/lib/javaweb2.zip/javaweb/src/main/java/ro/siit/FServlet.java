package ro.siit;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

/**
 * Created by FiatF on 9/26/2017.
 */
@WebServlet(urlPatterns = {"/fservlet"})
public class FServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("data", new Date());

        String[] names = new String[3];
        names[0] = "Ana";
        names[1] = "Dana";
        names[2] = "Liza";

        req.setAttribute("girls", names);

        req.getRequestDispatcher("/jsp/fservlet.jsp").forward(req, resp);
    }
}
