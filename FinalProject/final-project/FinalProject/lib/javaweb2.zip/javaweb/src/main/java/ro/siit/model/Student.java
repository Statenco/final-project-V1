package ro.siit.model;

/**
 * Created by FiatF on 9/28/2017.
 */
public class Student {
    private String CNP;
    private String name;

    public Student(String CNP, String name) {
        this.CNP = CNP;
        this.name = name;
    }

    public String getCNP() {
        return CNP;
    }

    public String getName() {
        return name;
    }
}
