CREATE TABLE students(
  cnp VARCHAR(13),
  name VARCHAR (30),
  PRIMARY KEY(cnp)
)