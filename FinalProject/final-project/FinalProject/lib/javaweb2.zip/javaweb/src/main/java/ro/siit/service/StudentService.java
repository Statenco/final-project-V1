package ro.siit.service;

import ro.siit.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by FiatF on 9/28/2017.
 */
public class StudentService {

    private static final StudentService instance = new StudentService();

    private Connection connection;

    private StudentService(){
        String connectionString = "jdbc:postgresql://localhost:5432/siit5?user=postgres&password=postgres";
        try {
            Class.forName("org.postgresql.Driver").newInstance();
            connection = DriverManager.getConnection(connectionString);
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Student> getStudents(){
        List<Student> outcome  = new ArrayList<Student>();

        ResultSet rs = null;

        try {
            Statement statement  = connection.createStatement();
            rs = statement.executeQuery("SELECT * FROM students");
            while(rs.next()){
                outcome.add(new Student(rs.getString("cnp"), rs.getString("name")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return outcome;
    }

    public void addStudent(Student student){
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO students VALUES (?, ?)");
            statement.setString(1, student.getCNP());
            statement.setString(2, student.getName());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateStudent(Student student){
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE students SET name = ? WHERE cnp = ?");
            statement.setString(2, student.getCNP());
            statement.setString(1, student.getName());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Student getStudent(String cnp){

        ResultSet rs = null;
        try {
            PreparedStatement statement  = connection.prepareStatement("SELECT * FROM students WHERE cnp = ?");
            statement.setString(1, cnp);
            rs = statement.executeQuery();
            while(rs.next()){
                return new Student(rs.getString("cnp"), rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void deleteStudent(String cnp){
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM students WHERE cnp = ?");
            statement.setString(1, cnp);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void finalize() throws Throwable {
        connection.close();
    }

    public static StudentService getInstance(){
        return instance;
    }
}
