package ro.siit.controller;

import ro.siit.model.Student;
import ro.siit.service.StudentService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by FiatF on 9/28/2017.
 */
@WebServlet(urlPatterns = {"/students"})
public class StudentController extends HttpServlet {
    public static final String ACTION = "action";
    public static final String LIST = "list";
    public static final String DELETE = "delete";
    public static final String SHOW_FORM = "showForm";
    public static final String ADD = "add";
    public static final String EDIT = "edit";

    public static final String STUDENTS_LIST = "studentsList";

    private StudentService studentService;

    @Override
    public void init() throws ServletException {
        this.studentService = StudentService.getInstance();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter(ACTION);
        if(action == null){
            action = LIST;
        }

        switch (action){
            case LIST:
                list(req, resp);
                break;
            case DELETE:
                studentService.deleteStudent(req.getParameter("id"));
                list(req, resp);
                break;
            case SHOW_FORM:
                Student student = studentService.getStudent(req.getParameter("id"));

                if(student != null){
                    req.setAttribute("action", "edit");
                    req.setAttribute("cnp", student.getCNP());
                    req.setAttribute("name", student.getName());
                    req.setAttribute("buttonLabel", "Update");
                }else{
                    req.setAttribute("action", "add");
                    req.setAttribute("buttonLabel", "Add");
                }
                req.getRequestDispatcher("/jsp/students/form.jsp").forward(req,resp);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter(ACTION);
        if(action == null){
            action = LIST;
        }

        switch (action){
            case LIST:
                list(req, resp);
                break;
            case ADD:
                studentService.addStudent(new Student(req.getParameter("cnp"), req.getParameter("name")));
                list(req, resp);
                break;
            case EDIT:
                studentService.updateStudent(new Student(req.getParameter("cnp"), req.getParameter("name")));
                list(req, resp);
                break;
        }
    }

    private void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Student> students = studentService.getStudents();
        req.setAttribute(STUDENTS_LIST, students);
        req.getRequestDispatcher("/jsp/students/list.jsp").forward(req,resp);
    }
}
